package bibliotheque.collegeuniversel.bibliotheque;; // <-- adapte au tien

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import bibliotheque.collegeuniversel.bibliotheque.R;

public class LibraryActivity extends AppCompatActivity {

    private LinearLayout booksContainer;
    private EditText etSearch;
    private Button btnFilterAll, btnFilterRoman, btnFilterSciFi, btnFilterFantasy;
    private Button btnTypeAll, btnTypePrint, btnTypeEbook, btnTypeAudio;

    private static class Book {
        String title, author, category, type, status;
        int available, total;
        Book(String title, String author, String category, String type, String status, int available, int total) {
            this.title = title; this.author = author; this.category = category; this.type = type;
            this.status = status; this.available = available; this.total = total;
        }
    }

    private final List<Book> allBooks = new ArrayList<>();
    private String currentCategory = "ALL";
    private String currentType = "ALL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        booksContainer   = findViewById(R.id.booksContainer);
        etSearch         = findViewById(R.id.etSearch);

        btnFilterAll     = findViewById(R.id.btnFilterAll);
        btnFilterRoman   = findViewById(R.id.btnFilterRoman);
        btnFilterSciFi   = findViewById(R.id.btnFilterSciFi);
        btnFilterFantasy = findViewById(R.id.btnFilterFantasy);

        btnTypeAll   = findViewById(R.id.btnTypeAll);
        btnTypePrint = findViewById(R.id.btnTypePrint);
        btnTypeEbook = findViewById(R.id.btnTypeEbook);
        btnTypeAudio = findViewById(R.id.btnTypeAudio);

        // Données démo
        allBooks.add(new Book("HARRY POTTER", "J.K. Rowling", "FANTASY", "Imprimé", "Disponible", 3, 5));
        allBooks.add(new Book("DUNE", "Frank Herbert", "SCI-FI", "E-book", "Emprunté", 0, 1));
        allBooks.add(new Book("L'ÉTRANGER", "Albert Camus", "ROMAN", "Audio", "Réservé", 0, 1));
        allBooks.add(new Book("1984", "George Orwell", "ROMAN", "Imprimé", "Disponible", 2, 4));

        // Filtres catégories
        btnFilterAll.setOnClickListener(v -> { currentCategory = "ALL"; renderBooks(); });
        btnFilterRoman.setOnClickListener(v -> { currentCategory = "ROMAN"; renderBooks(); });
        btnFilterSciFi.setOnClickListener(v -> { currentCategory = "SCI-FI"; renderBooks(); });
        btnFilterFantasy.setOnClickListener(v -> { currentCategory = "FANTASY"; renderBooks(); });

        // Filtres type
        btnTypeAll.setOnClickListener(v -> { currentType = "ALL"; renderBooks(); });
        btnTypePrint.setOnClickListener(v -> { currentType = "Imprimé"; renderBooks(); });
        btnTypeEbook.setOnClickListener(v -> { currentType = "E-book"; renderBooks(); });
        btnTypeAudio.setOnClickListener(v -> { currentType = "Audio"; renderBooks(); });

        // Recherche (Enter)
        etSearch.setOnEditorActionListener((tv, actionId, event) -> { renderBooks(); return true; });

        // Bouton retour
        findViewById(R.id.btnBackToAuth).setOnClickListener(v -> finish());

        // Premier rendu
        renderBooks();
    }

    private void renderBooks() {
        booksContainer.removeAllViews();
        String q = etSearch.getText().toString().trim().toLowerCase();

        for (Book b : allBooks) {
            boolean matchQuery = q.isEmpty()
                    || b.title.toLowerCase().contains(q)
                    || b.author.toLowerCase().contains(q);

            boolean matchCat = currentCategory.equals("ALL")
                    || b.category.equalsIgnoreCase(currentCategory);

            boolean matchType = currentType.equals("ALL")
                    || b.type.equalsIgnoreCase(currentType);

            if (matchQuery && matchCat && matchType) {
                booksContainer.addView(createBookCard(b));
            }
        }

        if (booksContainer.getChildCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Aucun livre trouvé.");
            empty.setPadding(8, 16, 8, 16);
            booksContainer.addView(empty);
        }
    }

    private View createBookCard(Book b) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(24, 24, 24, 24);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, 16);
        card.setLayoutParams(lp);
        card.setBackgroundColor(0xFFEFEFEF);

        TextView title = new TextView(this);
        title.setText("📘  " + b.title + "    ⭐");
        title.setTextSize(18f);

        TextView author = new TextView(this);
        author.setText(b.author + "    ♡");

        TextView meta = new TextView(this);
        meta.setText(b.category + " • " + b.type);

        String dot = "🟢";
        if ("Emprunté".equalsIgnoreCase(b.status)) dot = "🟠";
        else if ("Réservé".equalsIgnoreCase(b.status)) dot = "🔴";

        TextView status = new TextView(this);
        if ("Disponible".equalsIgnoreCase(b.status))
            status.setText(dot + " " + b.status + " • " + b.available + "/" + b.total + " exemplaires");
        else
            status.setText(dot + " " + b.status);

        card.addView(title);
        card.addView(author);
        card.addView(meta);
        card.addView(status);

        card.setOnClickListener(v -> Toast.makeText(this, "Détails: " + b.title, Toast.LENGTH_SHORT).show());
        return card;
    }
}
